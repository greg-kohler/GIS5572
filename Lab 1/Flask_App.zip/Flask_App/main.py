import arcpy
from flask import Flask, jsonify 
import psycopg2
from psycopg2 import sql

#Name App
app = Flask(__name__)

#Define database credentials
dbname = "gis5572"
dbuser = "postgres"
dbpass = ""
dbhost = "35.224.48.126"

with open(r"\database.txt", 'r') as file:
    database_key = file.read().strip()
    
#Connect to Database and Extract Geometry 
#App Route defines url
@app.route('/geojson_polygon')
def get_geojson():
    conn = psycopg2.connect(
        dbname=dbname,
        user=dbuser,
        password=database_key, #Should be database_key if not connecting to local 
        host= dbhost,
        port="5432"
        )
    
    cur = conn.cursor()

    query = """
        SELECT ST_AsGeoJSON(shape) AS geojson
        FROM lab15572
    """
    cur.execute(query)
    geojson_data = cur.fetchone()[0]
    cur.close()
    conn.close()

    #Puts the wkt in the GeomFromText 
    # Return the GeoJSON data
    return jsonify(geojson_data)

if __name__ == '__main__':
    #Change to app.run(debug=False) if not running on Google Cloud
    app.run(debug=True, host="0.0.0.0", port=int(os.environ.get("PORT", 8080)))
